//LAB 10 - 1 FAQ PAGE
//alert("1 - connected");

//$(document).ready(function(){          


	//$("p.contentBox").hide();

	//$("p.contentBox").click(function(){
		//$('contentBox').show();
	//});

    //$("p.contentBox").slideUp(1000); 

	//$("p").click(function(){
		//$('contentBox').toggle();
	//}); 
	
	//$("p.contentBox").click(function(){
		//$("contentBox").fadeToggle("slow");
	//});

	//$("h2").click(function(){
		//$(this).next("p.contentBox").slideToggle(1000);

	//});	
//});
